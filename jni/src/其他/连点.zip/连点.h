void 连点() {
bool 按下;

double tx = draw_style[20], ty = draw_style[21];
while (1) {
ImGuiIO& iooi = ImGui::GetIO();
if (DrawIo[48] ) {//写两段分别用于调整开火位置与判断按下
if (DrawIo[48]&& iooi.MouseDown[0] && iooi.MousePos.x <= draw_style[21] + (NumIo[7] * 0.5) && iooi.MousePos.y <= screen_y - draw_style[20] + (NumIo[7] * 0.5) && iooi.MousePos.x >= draw_style[21] - (NumIo[7] * 0.5) && iooi.MousePos.y >= screen_y - draw_style[20] - (NumIo[7] * 0.5)) {
if (DrawIo[48]&& iooi.MouseDown[0] && iooi.MousePos.x <= draw_style[21] + (NumIo[7] * 0.5) && iooi.MousePos.y <= screen_y - draw_style[20] + (NumIo[7] * 0.5) && iooi.MousePos.x >= draw_style[21] - (NumIo[7] * 0.5) && iooi.MousePos.y >= screen_y - draw_style[20] - (NumIo[7] * 0.5)) {
  while (DrawIo[48]&& iooi.MouseDown[0] && iooi.MousePos.x <= draw_style[21] + (NumIo[7] * 0.5) && iooi.MousePos.y <= screen_y - draw_style[20] + (NumIo[7] * 0.5) && iooi.MousePos.x >= draw_style[21] - (NumIo[7] * 0.5) && iooi.MousePos.y >= screen_y - draw_style[20] - (NumIo[7] * 0.5))
{
//usleep(50000);
usleep(100);
//draw_style[21] = iooi.MousePos.x;
//draw_style[20] = screen_y - iooi.MousePos.y;
绘制颜色[9] = ImColor(0, 220, 0, 150);
}
绘制颜色[9] = ImColor(255, 0, 0, 150);//未按下(红色)
}
}
} else if (DrawIo[49]) {
if (DrawIo[49]&& iooi.MouseDown[0] && iooi.MousePos.x <= draw_style[21] + (NumIo[7] * 0.5) && iooi.MousePos.y <= screen_y - draw_style[20] + (NumIo[7] * 0.5) && iooi.MousePos.x >= draw_style[21] - (NumIo[7] * 0.5) && iooi.MousePos.y >= screen_y - draw_style[20] - (NumIo[7] * 0.5)) {
if (DrawIo[49]&& iooi.MouseDown[0] && iooi.MousePos.x <= draw_style[21] + (NumIo[7] * 0.5) && iooi.MousePos.y <= screen_y - draw_style[20] + (NumIo[7] * 0.5) && iooi.MousePos.x >= draw_style[21] - (NumIo[7] * 0.5) && iooi.MousePos.y >= screen_y - draw_style[20] - (NumIo[7] * 0.5)) {
  while (DrawIo[49]&& iooi.MouseDown[0] && iooi.MousePos.x <= draw_style[21] + (NumIo[7] * 0.5) && iooi.MousePos.y <= screen_y - draw_style[20] + (NumIo[7] * 0.5) && iooi.MousePos.x >= draw_style[21] - (NumIo[7] * 0.5) && iooi.MousePos.y >= screen_y - draw_style[20] - (NumIo[7] * 0.5))
{
usleep(2000);
//usleep(draw_style[24] * 10000);
按下 = true;//按下
//printf("\n1\n");
}
按下 = false;//未按下(红色)
}
}
}

if (按下) {//判断按下后连点，连点区域
int random_offset_x = distribution_offset(generator);
int random_offset_y = distribution_offset(generator);

// 应用随机偏移量
int final_x = draw_style[22] + (random_offset_x * 0.5);
int final_y = draw_style[23] + (random_offset_y * 0.5);//因为我的随机点是±80，但是我怕开火键太小，我怕随机出开火键区域，点击不到开火键，所以乘以0.5

tx = final_x, ty = final_y;
// 恢复变量
// 抬起 
// 延迟

usleep(draw_style[24] * 10000);//这里面加一个乘以可以控制连点频率
if (!NumIo[10])
Touch_Down(8, (int)tx, (int)ty);
else
Touch_Down(8, screen_y - (int)tx, screen_x - (int)ty);
tx += 0;
ty += 0;

continue;
} else {
tx = 0, ty = 0;
Touch_Up(8);
continue;
}
if (!NumIo[10])
Touch_Down(8, (int)tx, (int)ty);
else
Touch_Down(8, screen_y - (int)tx, screen_x - (int)ty);
}
}